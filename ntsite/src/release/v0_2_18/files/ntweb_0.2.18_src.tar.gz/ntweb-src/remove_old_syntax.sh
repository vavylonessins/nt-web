#!/bin/sh
rm ~/.config/sublime-text/Packages/User/NTML.sublime-syntax 2>/dev/null
