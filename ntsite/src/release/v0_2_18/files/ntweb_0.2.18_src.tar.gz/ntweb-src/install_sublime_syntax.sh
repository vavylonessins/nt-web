#!/bin/sh
rm ~/.config/sublime-text/Packages/NTML.sublime-syntax 2>/dev/null
cp NTML.sublime-syntax ~/.config/sublime-text/Packages/NTML.sublime-syntax
