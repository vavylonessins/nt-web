python3 ntwc.py ntsite
